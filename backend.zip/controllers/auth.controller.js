exports.register = async(req,res) => {
    res.json({message:"register succcess"})
}
exports.login = async(req,res) => {
    res.json({message:"login succcess"})
}
exports.logout = async(req,res) => {
    res.json({message:"logout succcess"})
}