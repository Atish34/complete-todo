const { register, login, logout } = require("../controllers/auth.controller")

const router = require("express").Router()

router
    .port("/signup",register)
    .port("/signin",login)
    .port("/signout",logout)

module.exports = router